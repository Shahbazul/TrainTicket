package com.torryharris.driver;


import com.torryharris.jdbc.TrainDAO;
import com.torryharris.model.Ticket;
import com.torryharris.model.Train;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Date;
import java.util.Scanner;

public class TicketApplication {
    public static void main(String[] args) throws ParseException, SQLException, ClassNotFoundException, IOException {
        Scanner scan= new Scanner(System.in);

        System.out.println("Enter the Train Number");
        int trainNo= scan.nextInt();


        System.out.println("Enter Travel Date");
        String date=scan.next();
        Date date1  = new SimpleDateFormat("dd/MM/yyy").parse(date);
        Date date2 = new Date();
        if(date1.compareTo(date2) <= 0) {
            System.out.println("Travel Date is before current date");
            System.exit(0);
        }


        TrainDAO trainDAO = new TrainDAO();
        Ticket ticket=new Ticket(date1,trainDAO.findTrain(trainNo));
        System.out.println("Enter Number of Passengers");

        int numberOfPassengers=scan.nextInt();
        while (numberOfPassengers>0) {
            System.out.println("Enter Passenger Name");
            String name = scan.next();
            System.out.println("Enter Age");
            int age = scan.nextInt();
            System.out.println("Enter Gender(M/F)");
            char gender = scan.next().charAt(0);
            ticket.addPassenger(name,age,gender);
            numberOfPassengers--;
        }
        ticket.writeTicket();
    }
}
