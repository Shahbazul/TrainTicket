package com.torryharris.DAO;


import com.torryharris.model.UserRegDTO;

public interface UserDAO {
	
	public int registerUser(UserRegDTO user);


}
